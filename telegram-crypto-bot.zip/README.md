# Telegram Crypto Price Bot

ربات تلگرامی برای نمایش و تبدیل قیمت ارزهای دیجیتال به تومان با استفاده از CoinGecko API.

## دستورها
- /start
- /convert 1000000
- /convert btc 0.01
