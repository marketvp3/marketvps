import os
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes
import requests
from datetime import datetime

USD_IRR = 61500
GOLD_IRR = 7350000

COINS = {
    'btc': 'bitcoin',
    'eth': 'ethereum',
    'trx': 'tron',
    'usdt': 'tether',
    'bnb': 'binancecoin',
    'ada': 'cardano',
    'doge': 'dogecoin',
    'shiba': 'shiba-inu',
    'ltc': 'litecoin',
    'xrp': 'ripple'
}

COINGECKO_URL = f"https://api.coingecko.com/api/v3/simple/price?ids={','.join(COINS.values())}&vs_currencies=usd"

def format_price(price):
    return f"{price:,.0f}"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("💰 بیت‌کوین", callback_data='btc'),
         InlineKeyboardButton("💰 اتریوم", callback_data='eth')],
        [InlineKeyboardButton("💰 ترون", callback_data='trx'),
         InlineKeyboardButton("💰 تتر", callback_data='usdt')],
        [InlineKeyboardButton("💰 بایننس", callback_data='bnb'),
         InlineKeyboardButton("💰 کاردانو", callback_data='ada')],
        [InlineKeyboardButton("💰 دوج‌کوین", callback_data='doge'),
         InlineKeyboardButton("💰 شیبا", callback_data='shiba')],
        [InlineKeyboardButton("💰 لایت‌کوین", callback_data='ltc'),
         InlineKeyboardButton("💰 ریپل", callback_data='xrp')],
        [InlineKeyboardButton("💵 دلار", callback_data='usd')],
        [InlineKeyboardButton("🏅 طلای ۱۸ عیار", callback_data='gold')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("ارز موردنظر رو انتخاب کن:", reply_markup=reply_markup)

async def button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    try:
        data = requests.get(COINGECKO_URL).json()
    except:
        await query.edit_message_text("❌ خطا در دریافت قیمت‌ها!")
        return

    code = query.data
    if code == 'usd':
        message = f"💵 دلار: {format_price(USD_IRR)} تومان
🕒 {now}"
    elif code == 'gold':
        message = f"🏅 طلای ۱۸ عیار: {format_price(GOLD_IRR)} تومان
🕒 {now}"
    elif code in COINS:
        coin_id = COINS[code]
        price_usd = data.get(coin_id, {}).get('usd')
        if price_usd:
            price_irr = price_usd * USD_IRR
            message = f"💸 {code.upper()}:
${price_usd} ≈ {format_price(price_irr)} تومان
🕒 {now}"
        else:
            message = "❌ اطلاعات یافت نشد."
    else:
        message = "❓ گزینه ناشناخته."

    await query.edit_message_text(message)

async def convert(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = context.args
    if not args:
        await update.message.reply_text("❗ مثال:
/convert 1000000
/convert btc 0.01")
        return

    try:
        data = requests.get(COINGECKO_URL).json()

        prices = {k: data[v]['usd'] for k, v in COINS.items() if v in data}

        if len(args) == 1:
            value = args[0]

            if value.endswith('$'):
                dollar = float(value[:-1])
                toman = dollar * USD_IRR
                await update.message.reply_text(f"{dollar}$ ≈ {format_price(toman)} تومان")
            elif value.lower().endswith('usdt'):
                usdt = float(value[:-4])
                toman = usdt * prices['usdt'] * USD_IRR
                await update.message.reply_text(f"{usdt} تتر ≈ {format_price(toman)} تومان")
            else:
                toman = float(value)
                usd = toman / USD_IRR
                msg = f"🔁 {format_price(toman)} تومان برابر است با:
"
                for k, price in prices.items():
                    msg += f"- {usd / price:.6f} {k.upper()}
"
                await update.message.reply_text(msg)

        elif len(args) == 2:
            symbol = args[0].lower()
            amount = float(args[1])

            if symbol in prices:
                usd = amount * prices[symbol]
                toman = usd * USD_IRR
                await update.message.reply_text(f"{amount} {symbol.upper()} ≈ {format_price(toman)} تومان")
            elif symbol == 'usd':
                toman = amount * USD_IRR
                await update.message.reply_text(f"{amount}$ ≈ {format_price(toman)} تومان")
            else:
                await update.message.reply_text("❌ ارز نامعتبر. ارزهای پشتیبانی‌شده: " + ', '.join(COINS.keys()))
        else:
            await update.message.reply_text("❌ فرمت نادرست. مثال: /convert btc 0.01")

    except Exception as e:
        await update.message.reply_text(f"❌ خطا: {e}")

if __name__ == '__main__':
    TOKEN = os.getenv("BOT_TOKEN")
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler('start', start))
    app.add_handler(CommandHandler('convert', convert))
    app.add_handler(CallbackQueryHandler(button))
    print("🤖 ربات فعال شد...")
    app.run_polling()
